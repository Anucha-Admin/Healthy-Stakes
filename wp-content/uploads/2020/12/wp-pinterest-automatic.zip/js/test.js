jQuery(document).ready(function(){
	$$(cursor)
});

jQuery(document).ready(function() {
	$(cursor)
});

jQuery(document).ready(function() {
	
});