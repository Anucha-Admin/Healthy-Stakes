<?php 

   //wp-load
   require_once('../../../wp-load.php');
   
   wp_pinterest_automatic_pin_function();


?>